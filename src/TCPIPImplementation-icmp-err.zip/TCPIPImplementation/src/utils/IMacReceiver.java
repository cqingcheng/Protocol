package utils;

public interface IMacReceiver {
	public void  receiveMacAddress(byte[] ip, byte[] mac);
}
